import { create } from "zustand";
import { supabase } from "../services/supabase";

export const useUserStore = create((set) => ({
  // Estado global
  vestimenta: "enfermera",

  // Cambiar vestimenta y guardarla en Supabase
  setVestimenta: async (nuevaVestimenta, user_id) => {
    set({ vestimenta: nuevaVestimenta });

    if (!user_id) return;

    // Guardarla en Supabase (upsert para crear si no existe)
    const { error } = await supabase.from("selected_skin").upsert({
      paciente_id: user_id,
      skin_name: nuevaVestimenta,
    });

    if (error) console.error("Error guardando vestimenta:", error);
  },

  // Cargar vestimenta desde Supabase al entrar a la app
  loadVestimenta: async (user_id) => {
    const { data, error } = await supabase
      .from("selected_skin")
      .select("skin_name")
      .eq("paciente_id", user_id)
      .maybeSingle(); // maybeSingle() devuelve null si no existe

    if (!error && data?.skin_name) {
      set({ vestimenta: data.skin_name });
    }
  },
}));
