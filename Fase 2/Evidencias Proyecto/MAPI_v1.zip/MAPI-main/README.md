------------Iniciar el proyecto------------------

Tienen que tener instalado node.js

Abrir una terminal donde esta el proyecto

Ejecutar los siguiente comando:

-npm i

-npm start

Despues cada vez que quieran ejecutar iniciar el proyecto solo deben hacer
npm start
