import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { Picker } from '@react-native-picker/picker';
import { registerDoctor } from '../services/supabase';
import postalCodes from '../assets/cl_cods_post.json';

export default function DoctorRegister() {
  const router = useRouter();
  const [focusedInput, setFocusedInput] = useState(null);
  const [formData, setFormData] = useState({
    nombre: '',
    rut: '',
    id_especialidad: '',
    institucionMedica: '',
    codigoPostalInstitucion: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  
  // Función para limpiar el RUT
  function cleanRut(value) {
    if (!value) return '';
    return value.replace(/\.|\-|\s/g, '').toUpperCase();
  }

  // Función para formatear el RUT
  function formatRut(value) {
    const cleaned = cleanRut(value);

    if (cleaned.length === 0) return '';
    
    // El último carácter es el DV (dígito verificador)
    // El resto es el cuerpo del RUT
    const body = cleaned.slice(0, -1);
    const dv = cleaned.slice(-1);
    
    if (body.length === 0) return cleaned; // Solo se escribió el DV
    
    // Formatear según la longitud del cuerpo (sin DV)
    // Formato: X.XXX.XXX-X
    if (body.length === 1) {
      return body + '-' + dv;
    } else if (body.length === 2) {
      return body.slice(0, 1) + '.' + body.slice(1) + '-' + dv;
    } else if (body.length === 3) {
      return body.slice(0, 1) + '.' + body.slice(1) + '.' + body.slice(2) + '-' + dv;
    } else if (body.length === 4) {
      return body.slice(0, 1) + '.' + body.slice(1, 4) + '.' + body.slice(4) + '-' + dv;
    } else if (body.length === 5) {
      return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
    } else if (body.length === 6) {
      return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
    } else if (body.length === 7) {
      return body.slice(0, 1) + '.' + body.slice(1, 4) + '.' + body.slice(4) + '-' + dv;
    } else if (body.length === 8) {
      return body.slice(0, 2) + '.' + body.slice(2, 5) + '.' + body.slice(5) + '-' + dv;
    }
    
    return cleaned; // Si excede 8 dígitos, retornar sin formato
  }

  // Función para validar RUT usando el algoritmo del dígito verificador
  function validateRut(value) {
    const cleaned = cleanRut(value);
    if (!cleaned || cleaned.length < 2) return false;
    const body = cleaned.slice(0, -1);
    let dv = cleaned.slice(-1);
    dv = dv === 'K' ? 'K' : dv;
    if (!/^\d{7,8}$/.test(body)) return false;
    // Calcular el dígito verificador usando el algoritmo mod-11
    let sum = 0;
    let multiplier = 2;
    for (let i = body.length - 1; i >= 0; i--) {
      sum += parseInt(body.charAt(i), 10) * multiplier;
      multiplier = multiplier === 7 ? 2 : multiplier + 1;
    }
    const remainder = sum % 11;
    const expected = 11 - remainder;
    let expectedDv = '';
    if (expected === 11) expectedDv = '0';
    else if (expected === 10) expectedDv = 'K';
    else expectedDv = String(expected);
    return expectedDv === dv;
  }
  
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [postalValid, setPostalValid] = useState(null);
  const [postalInfo, setPostalInfo] = useState(null);

  // Procesar y cargar códigos postales desde el archivo JSON
  let postalSet = null;
  let postalMap = null;
  try {
    // Crear un mapa de códigos postales para validación rápida
    if (Array.isArray(postalCodes)) {
      const map = new Map();
      const list = postalCodes
        .map((item) => {
          if (item == null) return null;
          if (typeof item === 'object') {
            const code = item['Código Postal'] ?? item['codigo_postal'] ?? item.codigo ?? item.code ?? item.postal ?? null;
            if (code == null) return null;
            const cleaned = String(code).replace(/\D/g, '').padStart(7, '0');
            map.set(cleaned, item);
            return cleaned;
          }
          const cleaned = String(item).replace(/\D/g, '').padStart(7, '0');
          map.set(cleaned, item);
          return cleaned;
        })
        .filter(Boolean);
      postalSet = new Set(list);
      postalMap = map;
    }
  } catch (e) {
    postalSet = null;
    postalMap = null;
    console.warn('Error building postalSet from assets/cl_cods_post.json', e);
  }

  // Función para validar un código postal
  function isValidChilePostalCode(value) {
    if (value === undefined || value === null) return false;
    const cleaned = String(value).replace(/\D/g, '');
    if (!/^\d{7}$/.test(cleaned)) return false;
    if (!postalSet) return true;
    return postalSet.has(cleaned);
  }

  // Función para obtener información del código postal
  function getPostalInfo(value) {
    if (!postalMap) return null;
    const cleaned = String(value).replace(/\D/g, '');
    if (!/^\d{7}$/.test(cleaned)) return null;
    return postalMap.get(cleaned) ?? null;
  }

  // Valida todos los campos, RUT y código postal antes de enviar
  async function handleRegister() {
    setErrorMsg('');
    setSuccessMsg('');
    
    // Validar campos requeridos
    if (!formData.nombre || !formData.rut || !formData.email || !formData.password || !formData.confirmPassword) {
      setErrorMsg('Por favor completa todos los campos requeridos.');
      return;
    }
    if (!formData.id_especialidad) {
      setErrorMsg('Seleccione una especialidad.');
      return;
    }
    
    // Validar que las contraseñas coincidan
    if (formData.password !== formData.confirmPassword) {
      setErrorMsg('Las contraseñas no coinciden.');
      return;
    }
    
    // Validar RUT
    const rutValid = validateRut(formData.rut);
    if (!rutValid) {
      setErrorMsg('RUT inválido. Por favor verifica el RUT ingresado.');
      return;
    }

    // Validar código postal
    const postalOk = isValidChilePostalCode(formData.codigoPostalInstitucion || '');
    if (!postalOk) {
      setErrorMsg('Código postal inválido. Por favor verifica el código postal de la institución.');
      return;
    }

    // Formatear RUT antes de enviarlo
    const formattedRut = formatRut(formData.rut);
    setFormData(prev => ({ ...prev, rut: formattedRut }));

    setLoading(true);
    try {
      // Llamar función de registro desde servicio Supabase
      const { error, user } = await registerDoctor(formData);
      if (error) {
        setErrorMsg(error.message || 'Error al registrar. Intenta de nuevo.');
      } else {
        setSuccessMsg('Registro exitoso. Redirigiendo al login...');
        setTimeout(() => router.push('doctorLogin'), 1200);

      }
    } catch (err) {
      setErrorMsg('Error inesperado. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollViewContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.content}>
        <Text style={styles.title}>Registro Médico</Text>
        <Text style={styles.subtitle}>Complete sus datos para registrarse</Text>

        <View style={styles.form}>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Nombre Completo</Text>
            <TextInput
              style={[styles.input, focusedInput === 'nombre' && styles.inputFocused]}
              placeholder="Nombre completo"
              value={formData.nombre}
              onChangeText={(text) => setFormData({...formData, nombre: text})}
              onFocus={() => setFocusedInput('nombre')}
              onBlur={() => setFocusedInput(null)}
              autoCapitalize="words"
              placeholderTextColor="#999"
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>RUT</Text>
            <TextInput
              style={[styles.input, focusedInput === 'rut' && styles.inputFocused]}
              placeholder="00.000.000-K"
              value={formData.rut}
              onChangeText={(text) => {
                const filtered = text.replace(/[^0-9kK\.‑\s]/g, '');
                const cleaned = cleanRut(filtered);
                if (/^\d{7,8}[0-9Kk]$/.test(cleaned)) {
                  setFormData(prev => ({ ...prev, rut: formatRut(cleaned) }));
                } else {
                  setFormData(prev => ({ ...prev, rut: filtered }));
                }
              }}
              onFocus={() => setFocusedInput('rut')}
              onBlur={() => setFocusedInput(null)}
              keyboardType="default"
              placeholderTextColor="#999"
            />
            {formData.rut ? (
              validateRut(formData.rut) ? (
                <Text style={[styles.helperText, { color: '#2e7d32' }]}>✔ RUT válido</Text>
              ) : (
                <Text style={[styles.helperText, { color: '#d32f2f' }]}>✖ RUT inválido</Text>
              )
            ) : null}
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Correo Electrónico</Text>
            <TextInput
              style={[styles.input, focusedInput === 'email' && styles.inputFocused]}
              placeholder="ejemplo@correo.com"
              value={formData.email}
              onChangeText={(text) => setFormData({...formData, email: text})}
              onFocus={() => setFocusedInput('email')}
              onBlur={() => setFocusedInput(null)}
              keyboardType="email-address"
              autoCapitalize="none"
              placeholderTextColor="#999"
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Especialidad</Text>
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={formData.id_especialidad}
                onValueChange={(value) => setFormData({...formData, id_especialidad: value})}
                style={styles.picker}
                itemStyle={{ color: 'white', backgroundColor: '#7F7F7F' }}>
                <Picker.Item label="Seleccione especialidad..." value="" color="white" />
                <Picker.Item label="Endocrinología" value={1} color="white" />
                <Picker.Item label="Medicina Interna" value={2} color="white" />
                <Picker.Item label="Pediatría" value={3} color="white" />
                <Picker.Item label="Medicina Familiar" value={4} color="white" />
                <Picker.Item label="Nutrición y Dietética" value={5} color="white" />
                <Picker.Item label="Diabetólogo" value={6} color="white" />
              </Picker>
            </View>
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Institución Médica</Text>
            <TextInput
              style={[styles.input, focusedInput === 'institucion' && styles.inputFocused]}
              placeholder="Ej: Hospital San José"
              value={formData.institucionMedica}
              onChangeText={(text) => setFormData({...formData, institucionMedica: text})}
              onFocus={() => setFocusedInput('institucion')}
              onBlur={() => setFocusedInput(null)}
              autoCapitalize="words"
              placeholderTextColor="#999"
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Código Postal (Institución)</Text>
            <TextInput
              style={[styles.input, focusedInput === 'postal' && styles.inputFocused]}
              placeholder="Ej: 0000000"
              value={formData.codigoPostalInstitucion}
              onChangeText={(text) => {
                const filtered = text.replace(/\D/g, '');
                setFormData(prev => ({...prev, codigoPostalInstitucion: filtered}));
                if (filtered.length === 7) {
                  const ok = !!isValidChilePostalCode(filtered);
                  setPostalValid(ok);
                  setPostalInfo(ok ? getPostalInfo(filtered) : null);
                } else {
                  setPostalValid(null);
                  setPostalInfo(null);
                }
              }}
              onFocus={() => setFocusedInput('postal')}
              onBlur={() => {
                setFocusedInput(null);
                const value = formData.codigoPostalInstitucion || '';
                const ok = isValidChilePostalCode(value);
                setPostalValid(!!ok);
                setPostalInfo(ok ? getPostalInfo(value) : null);
              }}
              keyboardType="numeric"
              placeholderTextColor="#999"
            />
            {formData.codigoPostalInstitucion ? (
              postalValid === null ? (
                <Text style={styles.helperText}>Verificando código postal...</Text>
              ) : postalValid ? (
                postalInfo ? (
                  <Text style={[styles.helperText, { color: '#2e7d32' }]}>✔ Código postal válido — {postalInfo['Comuna/Localidad'] || postalInfo.comuna || ''}, {postalInfo['Región'] || postalInfo.region || ''}</Text>
                ) : (
                  <Text style={[styles.helperText, { color: '#2e7d32' }]}>✔ Código postal válido</Text>
                )
              ) : (
                <Text style={[styles.helperText, { color: '#d32f2f' }]}>✖ Código postal inválido</Text>
              )
            ) : null}
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Contraseña</Text>
            <TextInput
              style={[styles.input, focusedInput === 'password' && styles.inputFocused]}
              placeholder="Ingrese su contraseña"
              value={formData.password}
              onChangeText={(text) => setFormData({...formData, password: text})}
              onFocus={() => setFocusedInput('password')}
              onBlur={() => setFocusedInput(null)}
              secureTextEntry
              placeholderTextColor="#999"
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.label}>Confirmar Contraseña</Text>
            <TextInput
              style={[styles.input, focusedInput === 'confirmPassword' && styles.inputFocused]}
              placeholder="Confirme su contraseña"
              value={formData.confirmPassword}
              onChangeText={(text) => setFormData({...formData, confirmPassword: text})}
              onFocus={() => setFocusedInput('confirmPassword')}
              onBlur={() => setFocusedInput(null)}
              secureTextEntry
              placeholderTextColor="#999"
            />
          </View>

          {errorMsg ? <Text style={styles.errorText}>{errorMsg}</Text> : null}
          {successMsg ? <Text style={styles.successText}>{successMsg}</Text> : null}

          <TouchableOpacity style={styles.registerButton} onPress={handleRegister} disabled={loading}>
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.registerButtonText}>Registrarse</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.loginLink}
            onPress={() => router.push('doctorLogin')}
          >
            <Text style={styles.loginLinkText}>¿Ya tienes cuenta? Inicia sesión</Text>
          </TouchableOpacity>
        </View>
      </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#757575",
  },
  scrollView: {
    flex: 1,
  },
  scrollViewContent: {
    flexGrow: 1,
    paddingBottom: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
  },
  content: {
    flex: 1,
    padding: 24,
    justifyContent: 'space-between',
  },
  title: {
    fontSize: Platform.OS === 'web' ? 46 : 40,
    fontWeight: '800',
    color: "#ffffffff",
    marginBottom: Platform.OS === 'web' ? 8 : 4,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: Platform.OS === 'web' ? 20 : 16,
    color: "#ffffffff",
    marginBottom: Platform.OS === 'web' ? 32 : 24,
    textAlign: 'center',
    fontWeight: "500",
  },
  form: {
    width: '100%',
    maxWidth: 480,
    gap: Platform.OS === 'web' ? 16 : 12,
    alignSelf: 'center',
    backgroundColor: "#515151",
    borderRadius: 25,
    padding: 24,
    borderColor: "#afafafff",
    boxShadow: "0px 6px 6px 6px rgba(0, 0, 0, 0.1)",
  },
  inputContainer: {
    gap: Platform.OS === 'web' ? 8 : 6,
    marginBottom: Platform.OS === 'web' ? 0 : 4,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: "#ffffffff",
  },
  input: {
    width: '100%',
    padding: 16,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: "#7F7F7F",
    fontSize: 16,
    backgroundColor: "#7F7F7F",
    color: "white",
  },
  inputFocused: {
    borderWidth: 2,
    borderColor: "#ffffff",
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: "#7F7F7F",
    borderRadius: 25,
    overflow: 'hidden',
    backgroundColor: "#7F7F7F",
  },
  picker: {
    width: '100%',
    minHeight: Platform.OS === 'web' ? 48 : 56,
    paddingHorizontal: 16,
    paddingVertical: Platform.OS === 'web' ? 10 : 12,
    fontSize: 16,
    color: 'white',
    justifyContent: 'center',
    backgroundColor: "#7F7F7F",
  },
  uploadButton: {
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderStyle: 'dashed',
    borderColor: "#00897B",
    alignItems: 'center',
    backgroundColor: '#F5F9FF',
  },
  uploadButtonText: {
    color: '#00897B',
    fontSize: 16,
    fontWeight: '500',
  },
  helperText: {
    fontSize: 12,
    color: "#ffffffff",
    marginTop: 4,
  },
  registerButton: {
    width: '100%',
    padding: 16,
    backgroundColor: 'white',
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  registerButtonText: {
    color: '#515151',
    fontSize: 16,
    fontWeight: '600',
  },
  loginLink: {
    padding: 16,
    alignItems: 'center',
  },
  loginLinkText: {
    color: '#5EC7FF',
    fontSize: 14,
  },
  errorText: {
    color: '#ffcdd2',
    fontSize: 14,
    textAlign: 'center',
    marginVertical: 12,
  },
  successText: {
    color: '#c8e6c9',
    fontSize: 14,
    textAlign: 'center',
    marginVertical: 12,
  },
});
