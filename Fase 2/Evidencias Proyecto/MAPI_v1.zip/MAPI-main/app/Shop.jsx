import React, { useState, useEffect, useRef } from "react";
import {
  StyleSheet,
  View,
  Image,
  ScrollView,
  TextInput,
  ActivityIndicator,
  Text,
  Modal,
} from "react-native";

import { supabase } from "../services/supabase";

import { useAuthStore } from "../store/useAuthStore";

// Import de componentes
import { Points } from "../components/Points";
import { ItemShop } from "../components/ItemShop";
import { Header } from "../components/Header";
import itemsData from "../itemsInShop.json";

export default function Shop() {
  const [items, setItems] = useState([]);
  const user_id = useAuthStore((s) => s.pacienteId);
  useEffect(() => {
    const loadShop = async () => {
      // traer skins del usuario
      const { data: skinsComprados, error } = await supabase
        .from("skins")
        .select("skin_name")
        .eq("paciente_id", user_id);

      if (error) {
        console.error("Error fetching skins:", error);
      }

      const boughtNames = skinsComprados?.map((s) => s.skin_name) || [];

      // Asegurar que ENFERMERA SIEMPRE está comprada
      const realmenteCompradas = ["Enfermera", ...boughtNames];

      const processedItems = itemsData.map((item) => ({
        ...item,
        status: realmenteCompradas.includes(item.nombre) ? 0 : 1, // 0=comprado
      }));

      setItems(processedItems);
    };

    loadShop();
  }, []);

  const buyItem = async (item) => {
    try {
      // 1. Verificar si ya existe la skin
      const { data: existing, error: checkErr } = await supabase
        .from("skins")
        .select("id")
        .eq("paciente_id", user_id)
        .eq("skin_name", item.nombre)
        .maybeSingle();

      if (checkErr) {
        console.error("Error verificando skin existente:", checkErr);
        return;
      }

      // 2. Si existe → NO agregar
      if (existing) {
        console.log("Skin ya comprada, no se inserta de nuevo:", item.nombre);
        // Actualizar estado igual para que desaparezca el botón comprar
        setItems((prev) =>
          prev.map((i) => (i.id === item.id ? { ...i, status: 0 } : i))
        );
        return;
      }

      // 3. Insertar solo si NO existe
      const { error } = await supabase.from("skins").insert({
        paciente_id: user_id,
        skin_name: item.nombre,
      });

      if (error) {
        console.error("Error comprando skin:", error);
        return;
      }

      // 4. Actualizar estado local
      setItems((prev) =>
        prev.map((i) => (i.id === item.id ? { ...i, status: 0 } : i))
      );
    } catch (err) {
      console.error("buyItem exception:", err);
    }
  };

  return (
    <View style={[styles.content]}>
      <Header title="Tienda" />
      <View style={[styles.header]}>
        <Points />
      </View>

      <Text style={[styles.title]}>TIENDA</Text>
      <Text style={[styles.subTitle]}>Accesorios</Text>

      <ScrollView style={[styles.scroll]} showsVerticalScrollIndicator={false}>
        <View style={[styles.c_Items]}>
          {items.map((item) => {
            return (
              <ItemShop
                key={item.id}
                pStatus={item.status}
                pPrecio={item.precio}
                pItem={item.id}
                onBought={() => buyItem(item)}
              />
            );
          })}
          <View style={{ height: 100, width: "100%" }}></View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  content: {
    width: "100%",
    height: "100%",
    position: "relative",
    overflow: "scroll",
    backgroundColor: "white",
    flex: 1,
  },

  header: {
    position: "relative",
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    height: 70,
    //backgroundColor: "#ffb1b1ff",
    flexDirection: "row",
  },

  icons: {
    position: "absolute",
    top: 20,
    right: 20,
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
    //backgroundColor: "red"
  },

  title: {
    width: "100%",
    textAlign: "center",
    marginTop: 30,
    marginBlock: -15,
    fontSize: 50,
    fontFamily: "Arial",
    fontWeight: "900",
    color: "#4EA4FB",
    //backgroundColor: "#ffb1b1ff",
  },
  subTitle: {
    width: "100%",
    textAlign: "center",
    marginTop: 0,
    fontSize: 17,
    fontFamily: "Arial",
    fontWeight: "300",
    color: "#4EA4FB",
    //backgroundColor: "#ffb1b1ff",
  },

  c_Items: {
    maxWidth: "100%",
    flexDirection: "row",
    justifyContent: "center",
    flexWrap: "wrap",
  },

  scroll: {
    marginTop: 50,
  },
});
