import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Platform,
} from "react-native";
import { Header } from "../components/Header";
import CustomDropdown from "../components/CustomDropdown";

import { useUserStore } from "../store/useUserStore";
import { supabase } from "../services/supabase";
import { useAuthStore } from "../store/useAuthStore";

export default function Customizing() {
  //Id usuario
  const user_id = useAuthStore((s) => s.pacienteId);

  const vestimenta = useUserStore((state) => state.vestimenta);
  const setVestimenta = useUserStore((state) => state.setVestimenta);

  const [opciones, setOpciones] = useState(["Enfermera"]); // valor por defecto

  //Traer trajes desde Supabase
  useEffect(() => {
    const cargar = async () => {
      try {
        // Skins compradas
        const { data: skinsData } = await supabase
          .from("skins")
          .select("skin_name")
          .eq("paciente_id", user_id);

        const skinsCompradas = ["Enfermera"];

        if (skinsData) {
          skinsData.forEach((s) => {
            if (!skinsCompradas.includes(s.skin_name)) {
              skinsCompradas.push(s.skin_name);
            }
          });
        }

        setOpciones([...skinsCompradas]);

        // Skin seleccionada
        const { data: selectedData } = await supabase
          .from("selected_skin")
          .select("skin_name")
          .eq("paciente_id", user_id)
          .maybeSingle();

        let inicial = "Enfermera";

        if (selectedData && skinsCompradas.includes(selectedData.skin_name)) {
          inicial = selectedData.skin_name;
        }

        // Guardar en BD si no existe
        await supabase.from("selected_skin").upsert({
          paciente_id: user_id,
          skin_name: inicial,
        });

        setVestimenta(inicial);
      } catch (err) {
        console.error(err);
        setOpciones(["Enfermera"]);
        setVestimenta("Enfermera");
      }
    };

    cargar();
  }, []);

  const saveDress = async (skin) => {
    const { error } = await supabase.from("selected_skin").upsert({
      paciente_id: user_id,
      skin_name: skin,
    });
    if (error) console.error(error);
  };

  return (
    <View style={styles.container}>
      <Header title="Personalización" />

      <View style={{ padding: 20 }}>
        <CustomDropdown
          label="Selecciona tu vestimenta"
          options={opciones}
          value={vestimenta}
          onChange={(nuevaVestimenta) => {
            setVestimenta(nuevaVestimenta);
            saveDress(nuevaVestimenta);
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "white" },
  current: {
    fontSize: 16,
    marginBottom: 20,
    color: "#777",
  },
  option: {
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 10,
    backgroundColor: "#E9F4FF",
    marginBottom: 10,
  },
  selectedOption: {
    backgroundColor: "#6EA8FF",
  },
  optionText: {
    color: "#6EA8FF",
    fontSize: 16,
    fontWeight: "500",
  },
  selectedOptionText: {
    color: "white",
  },
});
