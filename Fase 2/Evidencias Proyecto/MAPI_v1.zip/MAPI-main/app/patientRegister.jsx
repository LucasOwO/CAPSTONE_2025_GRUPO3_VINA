import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import { supabase, getDoctorRutByUserId } from "../services/supabase";

export default function PatientRegister() {
  const router = useRouter();
  const [rut, setRut] = useState("");
  const [loading, setLoading] = useState(false);
  const [foundPatient, setFoundPatient] = useState(null);
  const [error, setError] = useState("");
  const [focusedInput, setFocusedInput] = useState(null);

  const [age, setAge] = useState("");
  const [emailInput, setEmailInput] = useState("");
  const [password, setPassword] = useState("");
  const [diabetesType, setDiabetesType] = useState("");

  // Función para limpiar el RUT
  function cleanRut(value) {
    if (!value) return "";
    return value.replace(/[^\dkK]/g, "").toUpperCase();
  }

  // Función para obtener solo el cuerpo del RUT (sin dígito verificador)
  function getRutBody(value) {
    const cleaned = cleanRut(value);
    if (cleaned.length < 2) return cleaned;
    return cleaned.slice(0, -1);
  }

  // Función para formatear el RUT
  function formatRut(value) {
    const cleaned = cleanRut(value);
    if (cleaned.length === 0) return "";
    const body = cleaned.slice(0, -1);
    const dv = cleaned.slice(-1);
    if (!body) return cleaned;
    const withDots = body.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return `${withDots}-${dv}`;
  }

  // Función para validar RUT
  function validateRut(value) {
    const cleaned = cleanRut(value);
    if (!cleaned || cleaned.length < 2) return false;
    const body = cleaned.slice(0, -1);
    let dv = cleaned.slice(-1);
    dv = dv === "K" ? "K" : dv;
    if (!/^\d{7,8}$/.test(body)) return false;
    let sum = 0;
    let multiplier = 2;
    for (let i = body.length - 1; i >= 0; i--) {
      sum += parseInt(body.charAt(i), 10) * multiplier;
      multiplier = multiplier === 7 ? 2 : multiplier + 1;
    }
    const remainder = sum % 11;
    const expected = 11 - remainder;
    let expectedDv = "";
    if (expected === 11) expectedDv = "0";
    else if (expected === 10) expectedDv = "K";
    else expectedDv = String(expected);
    return expectedDv === dv;
  }

  // Función para verificar si el RUT fue registrado por algún médico
  const handleCheckRut = async () => {
    setError("");
    setFoundPatient(null);
    const cleaned = cleanRut(rut);
    const rutBody = getRutBody(rut); // Solo el cuerpo, sin dígito verificador

    if (!cleaned || !validateRut(cleaned)) {
      setError("RUT inválido");
      return;
    }

    setLoading(true);

    try {
      // Verificar si el RUT existe en la tabla validacion (registrado por médico)
      const { data: validacionData, error: validacionErr } = await supabase
        .from("validacion")
        .select("*")
        .eq("rut", rutBody)
        .single();

      if (validacionErr || !validacionData) {
        setError("RUT no registrado por ningún médico");
        setLoading(false);
        return;
      }

      // Verificar si el paciente ya tiene cuenta (user_id)
      const { data: pacienteData } = await supabase
        .from("paciente")
        .select("user_id")
        .eq("rut", rutBody)
        .maybeSingle();

      if (pacienteData?.user_id) {
        setError("Este RUT ya tiene cuenta. Inicia sesión");
        setLoading(false);
        return;
      }

      // RUT válido, usar los datos guardados por el médico
      setFoundPatient({
        rut: rutBody,
        nombre: validacionData.nombre || "Paciente",
        edad: validacionData.edad || "",
        diabetes_type: validacionData.diabetes_type || "",
        doctor_user_id: validacionData.doctor_user_id || null,
      });

      // Pre-llenar los campos con los datos guardados
      setAge(String(validacionData.edad || ""));
      setDiabetesType(validacionData.diabetes_type || "");
      setEmailInput("");
      setLoading(false);
    } catch (err) {
      console.error("Error al verificar RUT:", err);
      setError("Error al verificar RUT. Intenta de nuevo");
      setLoading(false);
    }
  };

  // Función para crear la cuenta del paciente
  const handleCreateAccount = async () => {
    setError("");

    if (!foundPatient) {
      setError("Primero verifica el RUT");
      return;
    }

    if (!password || !emailInput) {
      setError("Completa email y contraseña");
      return;
    }

    if (emailInput.length < 5) {
      setError("Email inválido");
      return;
    }

    if (password.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres");
      return;
    }

    setLoading(true);
    const cleaned = cleanRut(rut);
    const rutBody = cleaned.slice(0, -1); // RUT sin dígito verificador

    try {
      // Crear usuario en Auth
      console.log(
        "[patientRegister] Creando usuario en Auth con email:",
        emailInput
      );
      const { data: authData, error: authErr } = await supabase.auth.signUp({
        email: emailInput,
        password,
      });

      if (authErr) {
        console.error("[patientRegister] Auth error:", authErr);

        // Mejorar mensajes de error específicos
        const message = (authErr.message || "").toLowerCase();
        let errorMessage = "Error al crear usuario";

        if (
          message.includes("already registered") ||
          message.includes("user already exists")
        ) {
          errorMessage = "Este correo ya está registrado";
        } else if (
          message.includes("password") &&
          message.includes("least 6")
        ) {
          errorMessage = "La contraseña debe tener al menos 6 caracteres";
        } else if (message.includes("invalid email")) {
          errorMessage = "Correo electrónico inválido";
        } else {
          errorMessage = authErr.message || "Error al crear usuario";
        }

        setError(errorMessage);
        setLoading(false);
        return;
      }

      if (!authData.user) {
        setError("Error al crear usuario. Intenta de nuevo");
        setLoading(false);
        return;
      }

      console.log("[patientRegister] Usuario Auth creado:", authData.user.id);

      // Extraer dígito verificador del RUT (último dígito)
      const digitoVerificador = cleaned.slice(-1); // Último dígito es el verificador

      // Crear nuevo registro en paciente con todos los datos
      console.log("[patientRegister] Creando nuevo paciente con:");
      console.log("[patientRegister] - rut:", rutBody);
      console.log("[patientRegister] - user_id:", authData.user.id);
      console.log("[patientRegister] - nombre:", foundPatient?.nombre);
      console.log("[patientRegister] - email:", emailInput);
      console.log("[patientRegister] - edad:", age);
      console.log("[patientRegister] - digito_verificador:", digitoVerificador);
      console.log(
        "[patientRegister] - doctor_user_id:",
        foundPatient?.doctor_user_id
      );

      if (!authData.user.id) {
        console.error(
          "[patientRegister] ERROR: authData.user.id es undefined o null!"
        );
        setError(
          "Error: No se pudo obtener el ID del usuario. Intenta de nuevo."
        );
        setLoading(false);
        return;
      }

      const insertResult = await supabase
        .from("paciente")
        .insert([
          {
            rut: rutBody, // Guardar solo la parte numérica del RUT
            user_id: authData.user.id,
            nombre: foundPatient?.nombre || "Paciente",
            email: emailInput,
            edad: parseInt(age, 10) || null,
            digito_verificador: digitoVerificador,
            doctor_user_id: foundPatient?.doctor_user_id || null, // Guardar el doctor_user_id
          },
        ])
        .select();

      const insertErr = insertResult.error;
      const insertData = insertResult.data;

      console.log("[patientRegister] Insert response - data:", insertData);
      console.log("[patientRegister] Insert response - error:", insertErr);

      if (insertErr) {
        console.error(
          "[patientRegister] Error al crear paciente:",
          insertErr.message || insertErr
        );
        setError(`Error: ${insertErr.message || "Error al guardar datos"}`);
        setLoading(false);
        return;
      }

      // Eliminar RUT de la tabla validacion después de crear la cuenta exitosamente
      console.log("[patientRegister] Eliminando RUT de validacion...");
      const { error: deleteValidacionErr, data: deleteData } = await supabase
        .from("validacion")
        .delete()
        .eq("rut", rutBody)
        .select(); // Devolver los registros eliminados para confirmar

      if (deleteValidacionErr) {
        console.error(
          "[patientRegister] Error al eliminar de validacion:",
          deleteValidacionErr.message || deleteValidacionErr
        );
      } else {
        console.log(
          "[patientRegister] ✓ Registros eliminados de validacion:",
          deleteData?.length || 0
        );
      }

      console.log("[patientRegister] Paciente creado exitosamente");
      console.log(
        "[patientRegister] Datos del paciente guardado:",
        insertData?.[0]
      );

      // CREAR TRATAMIENTO AUTOMÁTICAMENTE
      console.log(
        "[patientRegister] Creando tratamiento para paciente:",
        rutBody
      );
      console.log("[patientRegister] foundPatient:", foundPatient);

      // Obtener el doctor_user_id del paciente recién creado
      const doctorUserId = foundPatient?.doctor_user_id;
      const diabetesTypeFromValidacion = foundPatient?.diabetes_type;

      console.log("[patientRegister] Doctor user ID:", doctorUserId);
      console.log(
        "[patientRegister] Diabetes type:",
        diabetesTypeFromValidacion
      );

      if (doctorUserId) {
        try {
          // Obtener el RUT del médico usando la función de supabase
          console.log(
            "[patientRegister] Buscando doctor con auth_user_id:",
            doctorUserId
          );
          const {
            rut: rutMedico,
            digito_verificador: dvMedico,
            error: doctorErr,
          } = await getDoctorRutByUserId(doctorUserId);

          if (doctorErr) {
            console.error(
              "[patientRegister] Error al obtener RUT médico:",
              doctorErr.message
            );
          } else if (rutMedico) {
            console.log(
              "[patientRegister] RUT médico obtenido:",
              rutMedico,
              "DV:",
              dvMedico
            );

            // Crear tratamiento con RUT completo
            console.log("[patientRegister] Insertando tratamiento con:");
            console.log(
              "[patientRegister] - rut_medico:",
              rutMedico,
              "- dv_medico:",
              dvMedico
            );
            console.log(
              "[patientRegister] - rut_paciente:",
              rutBody,
              "- dv_paciente:",
              digitoVerificador
            );
            console.log("[patientRegister] - paciente_id:", authData.user.id);
            console.log(
              "[patientRegister] - tipo_diabetes:",
              diabetesTypeFromValidacion
            );

            const { data: tratamientoData, error: tratamientoErr } =
              await supabase
                .from("tratamiento")
                .insert([
                  {
                    rut_medico: rutMedico,
                    digito_verificador_medico: dvMedico,
                    rut_paciente: rutBody,
                    digito_verificador_paciente: digitoVerificador,
                    paciente_id: authData.user.id,
                    nombre_paciente: foundPatient?.nombre || "Paciente",
                    tipo_diabetes: diabetesTypeFromValidacion || null,
                  },
                ])
                .select();

            if (tratamientoErr) {
              console.error(
                "[patientRegister] Error al crear tratamiento:",
                tratamientoErr.message
              );
            } else {
              console.log(
                "[patientRegister] ✓ Tratamiento creado exitosamente:",
                tratamientoData?.[0]
              );
            }
          } else {
            console.warn("[patientRegister] No se encontró RUT médico");
          }
        } catch (e) {
          console.error(
            "[patientRegister] Exception al crear tratamiento:",
            e.message
          );
        }
      } else {
        console.warn(
          "[patientRegister] No hay doctorUserId, no se crea tratamiento"
        );
      }

      setLoading(false);
      // Redirigir a inicio de sesion
      router.replace("RoleSelection");
    } catch (err) {
      console.error("Error al crear cuenta:", err);
      setError("Error al crear cuenta. Intenta de nuevo");
      setLoading(false);
    }
  };

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.contentContainer}
    >
      <View style={styles.content}>
        <Text style={styles.title}>Activar Cuenta</Text>
        <Text style={styles.subtitle}>Paciente</Text>

        <View style={styles.form}>
          <TextInput
            style={[
              styles.input,
              focusedInput === "rut" && styles.inputFocused,
            ]}
            placeholder="RUT"
            value={rut}
            onChangeText={(text) => {
              const filtered = text.replace(/[^0-9kK\.‑\s]/g, "");
              const cleaned = cleanRut(filtered);
              if (/^\d{7,8}[0-9Kk]$/.test(cleaned)) {
                setRut(formatRut(cleaned));
              } else {
                setRut(filtered);
              }
            }}
            onFocus={() => setFocusedInput("rut")}
            onBlur={() => setFocusedInput(null)}
            editable={!loading && !foundPatient}
            placeholderTextColor="#ccc"
          />

          <TouchableOpacity
            style={[
              styles.verifyButton,
              (loading || foundPatient) && styles.verifyButtonDisabled,
            ]}
            onPress={handleCheckRut}
            disabled={loading || !!foundPatient}
          >
            {loading ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : foundPatient ? (
              <Text style={styles.verifyButtonText}>RUT Verificado ✓</Text>
            ) : (
              <Text style={styles.verifyButtonText}>Verificar RUT</Text>
            )}
          </TouchableOpacity>

          {error ? <Text style={styles.errorText}>{error}</Text> : null}

          {/* Si el RUT fue encontrado, mostrar formulario para crear cuenta */}
          {foundPatient ? (
            <>
              <Text style={styles.greetingText}>
                ¡Hola {foundPatient.nombre}!
              </Text>

              <TextInput
                style={[
                  styles.input,
                  focusedInput === "email" && styles.inputFocused,
                ]}
                placeholder="Email"
                value={emailInput}
                onChangeText={setEmailInput}
                onFocus={() => setFocusedInput("email")}
                onBlur={() => setFocusedInput(null)}
                keyboardType="email-address"
                autoCapitalize="none"
                editable={!loading}
                placeholderTextColor="#ccc"
              />

              <TextInput
                style={[
                  styles.input,
                  focusedInput === "password" && styles.inputFocused,
                ]}
                placeholder="Contraseña"
                value={password}
                onChangeText={setPassword}
                onFocus={() => setFocusedInput("password")}
                onBlur={() => setFocusedInput(null)}
                secureTextEntry
                editable={!loading}
                placeholderTextColor="#ccc"
              />

              <TouchableOpacity
                style={[
                  styles.createButton,
                  loading && styles.createButtonDisabled,
                ]}
                onPress={handleCreateAccount}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" size="small" />
                ) : (
                  <Text style={styles.createButtonText}>Crear Cuenta</Text>
                )}
              </TouchableOpacity>
            </>
          ) : null}

          <TouchableOpacity onPress={() => router.push("RoleSelection")}>
            <Text style={styles.registerButtonText}>
              ¿Ya estás registrado? ¡Inicia sesión aquí!
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ffffff",
  },
  contentContainer: {
    flexGrow: 1,
  },
  content: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  title: {
    fontSize: 32,
    fontWeight: "800",
    color: "#2196F3",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 18,
    color: "#666",
    marginBottom: 32,
  },
  form: {
    width: "100%",
    maxWidth: 360,
    gap: 16,
  },
  input: {
    width: "100%",
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#E0E0E0",
    fontSize: 16,
  },
  inputFocused: {
    borderWidth: 2,
    borderColor: "#2196F3",
  },
  verifyButton: {
    width: "100%",
    padding: 16,
    backgroundColor: "#2196F3",
    borderRadius: 12,
    alignItems: "center",
  },
  verifyButtonDisabled: {
    opacity: 0.6,
  },
  verifyButtonText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "600",
  },
  createButton: {
    width: "100%",
    padding: 16,
    backgroundColor: "#2196F3",
    borderRadius: 12,
    alignItems: "center",
    marginTop: 8,
  },
  createButtonDisabled: {
    opacity: 0.6,
  },
  createButtonText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "600",
  },
  errorText: {
    color: "#e53935",
    fontSize: 14,
    textAlign: "center",
    marginVertical: 12,
  },
  infoSection: {
    backgroundColor: "#e3f2fd",
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
    borderLeftColor: "#2196F3",
  },
  infoLabel: {
    fontSize: 12,
    fontWeight: "600",
    color: "#666",
    marginTop: 8,
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333",
    marginBottom: 8,
  },
  helperText: {
    fontSize: 12,
    color: "#666",
    marginTop: 4,
  },
  registerButtonText: {
    color: "#2196F3",
    fontSize: 14,
    textAlign: "center",
    padding: 16,
    fontWeight: "600",
  },
  greetingText: {
    fontSize: 24,
    fontWeight: "700",
    color: "#5EC7FF",
    textAlign: "center",
    marginVertical: 16,
  },
});
