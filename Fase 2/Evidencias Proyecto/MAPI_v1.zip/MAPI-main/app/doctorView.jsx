import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  Platform,
  FlatList,
  useWindowDimensions,
  Linking,
  Alert,
  Modal,
} from "react-native";
import { useRouter, useFocusEffect } from "expo-router";
import {
  getSession,
  logout,
  getDoctorByUserId,
  getPatientDocuments,
  uploadPatientDocument,
  deletePatientDocument,
  getPatientDocumentUrl,
  getTratamientosByMedico,
  finalizarTratamiento,
} from "../services/supabase";
import { supabase } from "../services/supabase";
import * as DocumentPicker from "expo-document-picker";

// Pantalla principal para médicos después de iniciar sesión
export default function DoctorView() {
  const router = useRouter();
  const { width } = useWindowDimensions();
  const isWeb = width > 768;
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [profile, setProfile] = useState(null);
  const [tratamientos, setTratamientos] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [patientDocuments, setPatientDocuments] = useState([]);
  const [uploadingDoc, setUploadingDoc] = useState(false);
  const [docStatus, setDocStatus] = useState("");
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [idTratamientoToFinalize, setIdTratamientoToFinalize] = useState(null);

  // Función para limpiar RUT
  function cleanRut(value) {
    if (!value) return "";
    return value.replace(/\.|\-|\s/g, "").toUpperCase();
  }

  // Función para formatear el RUT con el dígito verificador
  function formatRutCompleto(rutBody, digitoVerificador) {
    if (!rutBody) return "";
    const cleaned = String(rutBody).replace(/[^\dkK]/g, "").toUpperCase();
    const dv = String(digitoVerificador || "").toUpperCase();
    if (!cleaned) return dv;
    const withDots = cleaned.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return `${withDots}-${dv}`;
  }

  // Función para formatear el RUT
  function formatRut(value) {
    const cleaned = cleanRut(value);
    if (cleaned.length === 0) return "";
    const body = cleaned.slice(0, -1);
    const dv = cleaned.slice(-1);
    if (!body) return cleaned;
    const withDots = body.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return `${withDots}-${dv}`;
  }

  // Cargar datos del médico y tratamientos
  const loadDoctorData = async () => {
    setLoading(true);
    try {
      const { session, error: sessErr } = await getSession();
      if (sessErr || !session) {
        router.replace("doctorLogin");
        return;
      }

      const userId = session.user?.id;
      if (!userId) {
        router.replace("doctorLogin");
        return;
      }

      // Obtener perfil del médico
      const { profile, error: profErr } = await getDoctorByUserId(userId);
      if (profErr) {
        setName(session.user?.email ?? "");
      } else {
        setProfile(profile ?? null);
        setName(profile?.nombre ?? session.user?.email ?? "");
      }

      // Obtener tratamientos activos del médico (en tabla tratamiento)
      if (profile?.rut) {
        const { tratamientos: trats, error: tratsErr } = await getTratamientosByMedico(profile.rut);

        let tratamientosActivos = [];
        
        if (!tratsErr && trats) {
          
          // Para cada tratamiento, obtener datos del paciente y glucosa
          const tratamientosConDatos = await Promise.all(
            trats.map(async (trat) => {
              // Obtener nivel de glucosa del paciente usando el paciente_id directamente
              let glucosaValor = null;
              if (trat.paciente_id) {
                const { data: glucosaDataArray, error: glucosaErr } = await supabase
                  .from("glucosa")
                  .select("valor")
                  .eq("paciente_id", trat.paciente_id)
                  .order("created_at", { ascending: false })
                  .limit(1);
                
                if (!glucosaErr && glucosaDataArray && glucosaDataArray.length > 0) {
                  glucosaValor = glucosaDataArray[0].valor;
                }
              }

              return {
                ...trat,
                pacienteName: trat.nombre_paciente || "Paciente desconocido",
                tieneCuenta: !!trat.paciente_id,
                diabetesType: trat.tipo_diabetes,
                glucosa: glucosaValor,
                status: "activo",
              };
            })
          );

          tratamientosActivos = tratamientosConDatos || [];
        }

        // NOTA: Las cards de tratamiento SOLO se crean cuando el paciente se registra exitosamente
        // No hay tratamientos pendientes (rojos), solo activos (verdes)
        setTratamientos(tratamientosActivos);
      }
    } catch (err) {
      console.error("Error al cargar datos:", err);
    } finally {
      setLoading(false);
    }
  };

  // Cargar datos al montar y cuando se enfoca la pantalla
  useEffect(() => {
    let mounted = true;
    if (mounted) {
      loadDoctorData();
    }
    return () => {
      mounted = false;
    };
  }, []);

  // Recargar pacientes cuando vuelve a esta pantalla
  useFocusEffect(
    React.useCallback(() => {
      loadDoctorData();
    }, [])
  );

  // Función para cerrar sesión
  const handleLogout = async () => {
    setLoading(true);
    await logout();
    setLoading(false);
    router.replace("doctorLogin");
  };

  // Cargar documentos cuando se selecciona un tratamiento
  const handleSelectPatient = async (tratamiento) => {
    setSelectedPatient(tratamiento);
    setDocStatus("");
    setPatientDocuments([]);

    // Cargar documentos del paciente usando su nombre
    const { documents } = await getPatientDocuments(tratamiento.pacienteName);
    setPatientDocuments(documents || []);
  };

  // Finalizar un tratamiento
  const handleFinalizarTratamiento = async (idTratamiento) => {
    if (Platform.OS === 'web') {
      // En web, mostrar modal personalizado
      setIdTratamientoToFinalize(idTratamiento);
      setShowConfirmModal(true);
    } else {
      // En mobile, usar Alert nativo
      Alert.alert(
        "Finalizar Tratamiento",
        "¿Estás seguro de que deseas finalizar este tratamiento?",
        [
          { text: "Cancelar", onPress: () => {}, style: "cancel" },
          {
            text: "Finalizar",
            onPress: async () => {
              await proceedWithFinalize(idTratamiento);
            },
            style: "destructive",
          },
        ]
      );
    }
  };

  // Procesar la finalización del tratamiento
  const proceedWithFinalize = async (idTratamiento) => {
    setLoading(true);
    const { success, error } = await finalizarTratamiento(idTratamiento);
    
    if (success) {
      if (Platform.OS !== 'web') {
        Alert.alert("✓ Éxito", "Tratamiento finalizado correctamente");
      }
      setTimeout(() => {
        loadDoctorData();
        setShowConfirmModal(false);
      }, 500);
    } else {
      if (Platform.OS !== 'web') {
        Alert.alert("✗ Error", "Error al finalizar tratamiento: " + error);
      }
    }
    setLoading(false);
  };

  // Volver a la lista de pacientes
  const handleBackToList = () => {
    setSelectedPatient(null);
    setPatientDocuments([]);
    setDocStatus("");
  };

  // Seleccionar y subir documento para el tratamiento seleccionado
  const handleSelectDocument = async () => {
    if (!selectedPatient) return;

    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ["application/pdf"],
        copyToCacheDirectory: true,
      });

      if (result.canceled) {
        setDocStatus("Selección cancelada");
        return;
      }

      if (!result.assets || result.assets.length === 0) {
        setDocStatus("No se seleccionó ningún archivo");
        return;
      }

      const file = result.assets[0];
      const filename = file.name || `documento_${Date.now()}.pdf`;

      if (!filename.toLowerCase().endsWith(".pdf")) {
        setDocStatus("Error: Solo se permiten archivos PDF");
        return;
      }

      setDocStatus(`Cargando archivo: ${filename}...`);
      setUploadingDoc(true);

      const { publicUrl, error } = await uploadPatientDocument({
        fileUri: file.uri,
        filename: filename,
        patientId: selectedPatient.rut_paciente,
        patientName: selectedPatient.pacienteName,
      });

      if (error) {
        console.error("Upload error:", error);
        setDocStatus(`Error: ${String(error.message || error)}`);
      } else {
        setDocStatus("Documento subido correctamente");
        // Recargar lista de documentos
        const { documents } = await getPatientDocuments(selectedPatient.pacienteName);
        setPatientDocuments(documents || []);
        setTimeout(() => {
          setDocStatus("");
        }, 2000);
      }
    } catch (e) {
      console.error("Error al seleccionar documento:", e);
      setDocStatus(`Error: ${e.message}`);
    } finally {
      setUploadingDoc(false);
    }
  };

  // Eliminar documento del tratamiento
  const handleDeleteDocument = async (filename) => {
    if (!selectedPatient) return;

    try {
      setDocStatus(`Eliminando ${filename}...`);
      const { success, error } = await deletePatientDocument(
        selectedPatient.pacienteName,
        filename
      );

      if (error) {
        console.error("Delete error:", error);
        setDocStatus(`Error: ${String(error.message || error)}`);
      } else {
        setDocStatus("Documento eliminado correctamente");
        // Recargar lista de documentos
        const { documents } = await getPatientDocuments(selectedPatient.pacienteName);
        setPatientDocuments(documents || []);
        setTimeout(() => {
          setDocStatus("");
        }, 2000);
      }
    } catch (e) {
      console.error("Error al eliminar documento:", e);
      setDocStatus(`Error: ${e.message}`);
    }
  };

  // Abrir/Descargar documento
  const handleOpenDocument = async (filename) => {
    if (!selectedPatient) return;

    try {
      const { publicUrl, error } = await getPatientDocumentUrl(
        selectedPatient.pacienteName,
        filename
      );

      if (error || !publicUrl) {
        setDocStatus("Error al obtener el link del documento");
        return;
      }

      // Abrir el documento en el navegador
      Linking.openURL(publicUrl);
    } catch (e) {
      console.error("Error al abrir documento:", e);
      setDocStatus(`Error: ${e.message}`);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#7F7F7F" />
      </View>
    );
  }

  // Pantalla de detalles del tratamiento
  const renderPatientDetails = () => (
    <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={handleBackToList}
          style={styles.backButtonContainer}
        >
          <Text style={styles.backButton}>← Volver</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Documentos del Tratamiento</Text>
      </View>

      <View style={[
        styles.patientDetailCard,
        styles.treatmentCardActive
      ]}>
        <Text style={styles.cardTitle}>
          Tratamiento "{selectedPatient?.pacienteName}"
        </Text>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>RUT del Paciente:</Text>
          <Text style={styles.detailValue}>
            {formatRutCompleto(selectedPatient?.rut_paciente, selectedPatient?.digito_verificador_paciente)}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Tipo de Diabetes:</Text>
          <Text style={styles.detailValue}>
            {selectedPatient?.tipo_diabetes ? `Tipo ${selectedPatient.tipo_diabetes}` : "No especificado"}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Inicio del Tratamiento:</Text>
          <Text style={styles.detailValue}>
            {new Date(selectedPatient?.fecha_inicio).toLocaleDateString("es-CL")}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Glucosa Actual:</Text>
          <Text style={styles.detailValue}>
            {selectedPatient?.glucosa ? `${selectedPatient.glucosa} mg/dL` : "Sin registro"}
          </Text>
        </View>
      </View>

      <TouchableOpacity
        style={[
          styles.uploadDocButton,
          uploadingDoc && styles.uploadDocButtonDisabled,
        ]}
        onPress={handleSelectDocument}
        disabled={uploadingDoc}
      >
        <Text style={styles.uploadDocButtonText}>
          {uploadingDoc ? "Cargando..." : "Seleccionar y cargar Documento"}
        </Text>
      </TouchableOpacity>

      {docStatus ? (
        <View
          style={[
            styles.docStatusBox,
            docStatus.includes("Error") && styles.docStatusError,
          ]}
        >
          <Text
            style={[
              styles.docStatusText,
              docStatus.includes("Error") && styles.docStatusErrorText,
            ]}
          >
            {docStatus}
          </Text>
        </View>
      ) : null}

      <View style={styles.documentsSection}>
        <Text style={styles.documentsTitle}>
          Documentos ({patientDocuments.length})
        </Text>

        {patientDocuments.length === 0 ? (
          <View style={styles.noDocuments}>
            <Text style={styles.noDocumentsText}>Sin documentos aún</Text>
          </View>
        ) : (
          patientDocuments.map((doc, index) => (
            <View key={index} style={styles.documentItemContainer}>
              <TouchableOpacity
                style={styles.documentItemContent}
                onPress={() => handleOpenDocument(doc.name)}
              >
                <Text style={styles.documentItemName} numberOfLines={2}>
                  📄 {doc.name}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.deleteDocButton}
                onPress={() => handleDeleteDocument(doc.name)}
              >
                <Text style={styles.deleteDocButtonText}>🗑️</Text>
              </TouchableOpacity>
            </View>
          ))
        )}
      </View>

      <View style={styles.bottomSpacer} />
    </ScrollView>
  );

  const renderHome = () => (
    <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.greeting}>¡Hola Dr. {name}!</Text>
        <Text style={styles.subGreeting}>Tus tratamientos en progreso</Text>
      </View>

      <View style={styles.statsCard}>
        <Text style={styles.statsNumber}>{tratamientos.length}</Text>
        <Text style={styles.statsLabel}>Tratamientos Activos</Text>
      </View>

      {tratamientos.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>
            No hay tratamientos registrados aún
          </Text>
          <Text style={styles.emptyStateSubText}>
            Usa la opción "Agregar Paciente" para comenzar
          </Text>
        </View>
      ) : (
        <View>
          <Text style={styles.patientsListTitle}>Mis Tratamientos</Text>
          <FlatList
            data={tratamientos}
            keyExtractor={(item) => item.id_tratamiento}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => handleSelectPatient(item)}
                style={[
                  styles.treatmentCard,
                  styles.treatmentCardActive
                ]}
              >
                <View style={styles.treatmentHeader}>
                  <View style={styles.treatmentInfo}>
                    <Text style={styles.treatmentTitle}>
                      Tratamiento "{item.pacienteName}"
                    </Text>
                    <Text style={styles.treatmentRut}>
                      RUT: {formatRutCompleto(item.rut_paciente, item.digito_verificador_paciente)}
                    </Text>
                  </View>
                  <View 
                    style={[
                      styles.statusBadge,
                      styles.statusBadgeActive
                    ]}
                  >
                    <Text style={styles.statusBadgeText}>
                      ✓ Activo
                    </Text>
                  </View>
                </View>

                <View style={styles.treatmentDetails}>
                  {item.tipo_diabetes && (
                    <Text style={styles.detailText}>
                      🩺 Diabetes Tipo {item.tipo_diabetes}
                    </Text>
                  )}
                  <Text style={styles.detailText}>
                    📅 Inicio: {new Date(item.fecha_inicio).toLocaleDateString("es-CL")}
                  </Text>
                  <Text style={styles.detailText}>
                    🩸 Glucosa: {item.glucosa ? `${item.glucosa} mg/dL` : "Sin registro"}
                  </Text>
                </View>

                <View style={styles.treatmentFooter}>
                  <TouchableOpacity 
                    style={styles.viewDocsButton}
                    onPress={() => {
                      setSelectedPatient(item);
                      setPatientDocuments([]);
                    }}
                  >
                    <Text style={styles.viewDocsText}>
                      Ver Documentos →
                    </Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={styles.finalizarButton}
                    onPress={() => handleFinalizarTratamiento(item.id_tratamiento)}
                  >
                    <Text style={styles.finalizarText}>
                      ✓ Finalizar
                    </Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            )}
            scrollEnabled={false}
          />
        </View>
      )}

      <View style={styles.bottomSpacer} />
    </ScrollView>
  );

  return (
    <View style={styles.container}>
      {selectedPatient ? renderPatientDetails() : renderHome()}

      <View style={styles.navbar}>
        <TouchableOpacity style={styles.navItem} onPress={() => {}}>
          <Text style={styles.navItemText}>📊 Inicio</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          onPress={() => router.push("addPatient")}
        >
          <Text style={styles.navItemText}>➕ Agregar Paciente</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.navItem}
          onPress={() => router.push("doctorCertificates")}
        >
          <Text style={styles.navItemText}>👤 Tu Perfil</Text>
        </TouchableOpacity>
      </View>

      {/* Modal de confirmación para web */}
      {Platform.OS === 'web' && (
        <Modal
          transparent={true}
          visible={showConfirmModal}
          onRequestClose={() => setShowConfirmModal(false)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Finalizar Tratamiento</Text>
              <Text style={styles.modalMessage}>
                ¿Estás seguro de que deseas finalizar este tratamiento?
              </Text>
              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalButtonCancel}
                  onPress={() => setShowConfirmModal(false)}
                >
                  <Text style={styles.modalButtonCancelText}>Cancelar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.modalButtonConfirm}
                  onPress={() => {
                    proceedWithFinalize(idTratamientoToFinalize);
                  }}
                >
                  <Text style={styles.modalButtonConfirmText}>Finalizar</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  content: {
    flex: 1,
    paddingTop: Platform.OS === "ios" ? 60 : 40,
    paddingHorizontal: 16,
    paddingBottom: 120, // Espacio para el navbar y botones del sistema
  },
  header: {
    marginBottom: 24,
    paddingVertical: 16,
  },
  greeting: {
    fontSize: 28,
    fontWeight: "800",
    color: "#7F7F7F",
    marginBottom: 4,
  },
  subGreeting: {
    fontSize: 14,
    color: "#7F7F7F",
  },
  profileCard: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
    marginBottom: 12,
  },
  profileInfo: {
    gap: 8,
  },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  infoLabel: {
    fontSize: 13,
    color: "#7F7F7F",
    fontWeight: "500",
  },
  infoValue: {
    fontSize: 13,
    color: "#333",
    fontWeight: "600",
  },
  statsCard: {
    backgroundColor: "#7F7F7F",
    borderRadius: 12,
    padding: 20,
    alignItems: "center",
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 4,
  },
  statsNumber: {
    fontSize: 32,
    fontWeight: "800",
    color: "#fff",
  },
  statsLabel: {
    fontSize: 14,
    color: "#fff",
    marginTop: 4,
    opacity: 0.9,
  },
  // Estilos para la sección de pacientes
  patientsListTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#333",
    marginBottom: 12,
    marginTop: 8,
  },
  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 40,
  },
  emptyStateText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#7F7F7F",
    marginBottom: 4,
  },
  emptyStateSubText: {
    fontSize: 13,
    color: "#7F7F7F",
  },
  patientListContent: {
    paddingBottom: 16,
  },
  patientCard: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 14,
    marginBottom: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2,
    elevation: 2,
  },
  treatmentCard: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  treatmentCardActive: {
    borderColor: "#4caf50", // Verde cuando está activo
  },
  treatmentCardPending: {
    borderColor: "#e53935", // Rojo cuando está pendiente
  },
  treatmentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 12,
  },
  treatmentInfo: {
    flex: 1,
    paddingRight: 12,
  },
  treatmentTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#333",
    marginBottom: 4,
  },
  treatmentRut: {
    fontSize: 13,
    color: "#7F7F7F",
    fontWeight: "500",
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    minWidth: 80,
    alignItems: "center",
  },
  statusBadgeActive: {
    backgroundColor: "#e8f5e9",
  },
  statusBadgePending: {
    backgroundColor: "#fff3e0",
  },
  statusBadgeText: {
    fontSize: 12,
    fontWeight: "600",
  },
  treatmentDetails: {
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
    gap: 6,
  },
  detailText: {
    fontSize: 12,
    color: "#666",
    lineHeight: 18,
  },
  treatmentFooter: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 8,
  },
  viewDocsButton: {
    flex: 1,
  },
  viewDocsText: {
    fontSize: 12,
    color: "#7F7F7F",
    fontWeight: "600",
  },
  finalizarButton: {
    backgroundColor: "#FF6B6B",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    marginLeft: 12,
  },
  finalizarText: {
    fontSize: 12,
    color: "#fff",
    fontWeight: "600",
  },
  patientInfo: {
    flex: 1,
  },
  patientName: {
    fontSize: 15,
    fontWeight: "700",
    color: "#333",
    marginBottom: 2,
  },
  patientRut: {
    fontSize: 12,
    color: "#7F7F7F",
    marginBottom: 2,
  },
  patientDiabetes: {
    fontSize: 12,
    color: "#7F7F7F",
    fontWeight: "500",
    marginBottom: 2,
  },
  patientDate: {
    fontSize: 11,
    color: "#7F7F7F",
  },
  patientBadge: {
    backgroundColor: "#efefef",
    borderRadius: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  badgeText: {
    fontSize: 11,
    color: "#7F7F7F",
    fontWeight: "600",
  },
  // Estilos para vista de detalles del paciente
  backButtonContainer: {
    marginBottom: 12,
  },
  backButton: {
    fontSize: 14,
    color: "#7F7F7F",
    fontWeight: "600",
  },
  title: {
    fontSize: 24,
    fontWeight: "800",
    color: "#333",
  },
  patientDetailCard: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#333",
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  detailLabel: {
    fontSize: 13,
    color: "#7F7F7F",
    fontWeight: "500",
  },
  detailValue: {
    fontSize: 13,
    color: "#333",
    fontWeight: "600",
  },
  uploadDocButton: {
    backgroundColor: "#7F7F7F",
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: "center",
    marginBottom: 12,
  },
  uploadDocButtonDisabled: {
    opacity: 0.6,
  },
  uploadDocButtonText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
  docStatusBox: {
    backgroundColor: "#e8f5e9",
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    borderLeftWidth: 4,
    borderLeftColor: "#4caf50",
  },
  docStatusError: {
    backgroundColor: "#ffebee",
    borderLeftColor: "#e53935",
  },
  docStatusText: {
    color: "#2e7d32",
    fontSize: 12,
    fontWeight: "500",
  },
  docStatusErrorText: {
    color: "#c62828",
  },
  documentsSection: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  documentsTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#333",
    marginBottom: 12,
  },
  noDocuments: {
    paddingVertical: 20,
    alignItems: "center",
  },
  noDocumentsText: {
    fontSize: 14,
    color: "#999",
    fontStyle: "italic",
  },
  documentItemContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderLeftColor: "#7F7F7F",
  },
  documentItemContent: {
    flex: 1,
    marginRight: 8,
  },
  documentItemName: {
    fontSize: 13,
    color: "#333",
    fontWeight: "500",
  },
  deleteDocButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: "#ffebee",
    borderRadius: 6,
  },
  deleteDocButtonText: {
    fontSize: 16,
  },
  bottomSpacer: {
    height: 20,
  },
  // Estilos del navbar
  navbar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "#fff",
    flexDirection: "row",
    paddingBottom: Platform.OS === "ios" ? 30 : 50,
    paddingTop: 8,
    paddingHorizontal: 8,
    borderTopWidth: 1,
    borderTopColor: "#eee",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
    justifyContent: "center",
    alignItems: "center",
    flexWrap: "wrap",
  },
  navItem: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 4,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 8,
    minWidth: 80,
  },
  navItemText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#7F7F7F",
    textAlign: "center",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 24,
    minWidth: 300,
    maxWidth: 400,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#333",
    marginBottom: 12,
  },
  modalMessage: {
    fontSize: 14,
    color: "#666",
    marginBottom: 24,
    lineHeight: 20,
  },
  modalButtons: {
    flexDirection: "row",
    gap: 12,
    justifyContent: "flex-end",
  },
  modalButtonCancel: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 6,
    backgroundColor: "#f0f0f0",
  },
  modalButtonCancelText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333",
  },
  modalButtonConfirm: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 6,
    backgroundColor: "#e53935",
  },
  modalButtonConfirmText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#fff",
  },
});
