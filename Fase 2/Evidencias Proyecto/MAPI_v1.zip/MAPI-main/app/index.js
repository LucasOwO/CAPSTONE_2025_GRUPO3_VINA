import RoleSelection from "./RoleSelection";
import Welcome from "./Welcome";
import Main from "./Main";
import Shop from "./Shop";

export default function Index() {
  return <Welcome />;
}
