import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://zmmtdshapymhnfywolln.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InptbXRkc2hhcHltaG5meXdvbGxuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI0NDU4NzcsImV4cCI6MjA3ODAyMTg3N30.jZ3FI2_RyFapA-c1XK5V84FaTaZSwfPvWd2ngXefj0M';
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Registra un nuevo médico en la aplicación
// Crea una cuenta de autenticación en Supabase Auth y agrega los datos del médico en la tabla 'doctor'
export async function registerDoctor(formData) {
	const { email, password, nombre, rut, id_especialidad, institucionMedica, codigoPostalInstitucion } = formData;
	
	// Limpiar el RUT para obtener la parte numérica y el dígito verificador
	const cleanedRut = rut.replace(/[^\dkK]/g, '').toUpperCase();
	const rutBody = cleanedRut.slice(0, -1); // Parte numérica
	const digitoVerificador = cleanedRut.slice(-1); // Dígito verificador
	
	// Crear usuario de autenticación con email y contraseña
	const { data, error: signUpError } = await supabase.auth.signUp({ email, password });
	if (signUpError) {
		// Traducir errores comunes de registro
		const message = (signUpError.message || '').toLowerCase();
		let errorMessage = 'Error al registrar. Intenta de nuevo.';
		
		if (message.includes('password') && message.includes('6 characters')) {
			errorMessage = 'La contraseña debe tener al menos 6 caracteres.';
		} else if (message.includes('already registered') || message.includes('user already exists')) {
			errorMessage = 'Este correo ya está registrado. Intenta con otro correo.';
		} else if (message.includes('invalid email')) {
			errorMessage = 'Correo electrónico inválido. Verifica tu correo.';
		}
		
		const translatedError = new Error(errorMessage);
		return { error: translatedError };
	}

	// Obtener los datos del usuario creado
	const user = data?.user || null;

	// Construir objeto base con datos comunes del médico
	const baseRow = {
		rut: rutBody,
		digito_verificador: digitoVerificador,
		auth_user_id: user?.id || null,
		nombre,
		institucion_medica: institucionMedica,
		codigo_postal_institucion: codigoPostalInstitucion,
		email,
	};

	// Intentar normalizar el ID de especialidad a número
	const variants = [];
	let parsedEspecialidad = null;
	if (id_especialidad !== undefined && id_especialidad !== '') {
		if (typeof id_especialidad === 'number') {
			parsedEspecialidad = id_especialidad;
		} else if (/^\d+$/.test(String(id_especialidad))) {
			parsedEspecialidad = parseInt(String(id_especialidad), 10);
		}
	}
	
	// Crear variantes del registro: con especialidad
	if (parsedEspecialidad !== null) {
		variants.push({ ...baseRow, id_especialidad: parsedEspecialidad });
	} else {
		variants.push({ ...baseRow, id_especialidad: null });
		variants.push({ ...baseRow });
	}

	// Intentar insertar el registro médico en la tabla 'doctor' con diferentes variantes
	let lastError = null;
	for (const row of variants) {
		try {
			console.debug('Attempting insert into doctor with row keys:', Object.keys(row), 'row:', row);
			const { error: insertError } = await supabase.from('doctor').insert([row]);
			if (!insertError) {
				return { user };
			}
			lastError = insertError;
			const msg = String(insertError.message || insertError);
			console.warn('doctor insert failed:', msg);
			continue;
		} catch (e) {
			lastError = e;
			console.warn('doctor insert threw:', e?.message || e);
			continue;
		}
	}
	
	// Si falló la inserción, crear error con mensaje específico
	if (lastError) {
		const message = (lastError.message || '').toLowerCase();
		let errorMessage = 'Error al registrar. Intenta de nuevo.';
		
		if (message.includes('duplicate') || message.includes('rut')) {
			errorMessage = 'Este RUT ya está registrado.';
		} else if (message.includes('email')) {
			errorMessage = 'Este correo ya está registrado.';
		}
		
		const translatedError = new Error(errorMessage);
		return { error: translatedError };
	}
	
	return { error: lastError };
}

// Inicia sesión de un médico existente
// Valida credenciales y recupera el perfil completo del médico
export async function loginDoctor({ email, password }) {
	const { data, error: signInError } = await supabase.auth.signInWithPassword({ email, password });
	if (signInError) {
		return { error: true };
	}
	const user = data?.user || null;
	if (!user) {
		return { error: true };
	}
	try {
		const { data: profile, error: profileErr } = await supabase
			.from('doctor')
			.select('*')
			.eq('auth_user_id', user.id)
			.single();

		if (profileErr) {
			return { error: true };
		}
		return { user, profile };
	} catch (e) {
		return { error: true };
	}
}

// Inicia sesión de un paciente existente
// Valida credenciales y recupera el perfil completo del paciente
export async function loginPatient({ rut, password }) {
	try {
		// Buscar al paciente por RUT
		const cleaned = rut.replace(/[^\dkK]/g, "").toUpperCase();
		// Separar el RUT en cuerpo y dígito verificador
		const rutBody = cleaned.slice(0, -1); // Solo el cuerpo del RUT
		const rutAsNumber = parseInt(rutBody); // Convertir a número
		
		console.log('[loginPatient] RUT ingresado:', rut);
		console.log('[loginPatient] RUT body (número):', rutAsNumber);
		
		const { data: pacienteData, error: findErr } = await supabase
			.from('paciente')
			.select('*')
			.eq('rut', rutAsNumber)
			.single();

		if (findErr) {
			console.error('[loginPatient] Error al buscar paciente:', findErr.message);
			return { error: true };
		}

		if (!pacienteData) {
			console.error('[loginPatient] Paciente no encontrado');
			return { error: true };
		}

		console.log('[loginPatient] Paciente encontrado:', pacienteData.rut);

		// Si el paciente no tiene user_id, no tiene cuenta
		if (!pacienteData.user_id) {
			console.error('[loginPatient] Paciente sin user_id (sin cuenta)');
			return { error: true };
		}

		// Usar SOLO el email guardado en la tabla paciente (que fue usado en registro)
		if (!pacienteData.email) {
			console.error('[loginPatient] Paciente sin email en BD');
			return { error: true };
		}

		console.log('[loginPatient] Email del paciente en BD:', pacienteData.email);

		// Intentar login con el email guardado del paciente
		const { data, error: signInError } = await supabase.auth.signInWithPassword({
			email: pacienteData.email,
			password
		});

		if (signInError) {
			console.error('[loginPatient] Error en Auth:', signInError.message);
			return { error: true };
		}

		const user = data?.user || null;
		if (!user) {
			console.error('[loginPatient] Usuario Auth no retornado');
			return { error: true };
		}

		console.log('[loginPatient] Login exitoso con user:', user.id);
		return { user, paciente: pacienteData };
	} catch (e) {
		console.error('[loginPatient] Exception:', e.message);
		return { error: true };
	}
}

// Obtiene la sesión actual del usuario autenticado
// Retorna los datos de sesión si existe una sesión activa
export async function getSession() {
	try {
		const { data, error } = await supabase.auth.getSession();
		if (error) return { error };
		return { session: data?.session ?? null };
	} catch (e) {
		return { error: e };
	}
}

// Cierra la sesión del usuario actual
// Invalida el token de autenticación
export async function logout() {
	try {
		const { error } = await supabase.auth.signOut();
		return { error };
	} catch (e) {
		return { error: e };
	}
}

// Obtiene el perfil completo de un médico por su ID de usuario
// Busca en la tabla 'doctor' el registro asociado al usuario
export async function getDoctorByUserId(userId) {
	try {
		const { data, error } = await supabase
			.from('doctor')
			.select('*')
			.eq('auth_user_id', userId)
			.single();
		if (error) return { error };
		return { profile: data };
	} catch (e) {
		return { error: e };
	}
}

// Sube un certificado de un médico al bucket `docsDoctor` dentro de la carpeta `certificados`
// Retorna: { publicUrl } o { error }
export async function uploadDoctorCertificate({ fileUri, filename, doctorUserId, doctorName }) {
	try {
		// Validar que el filename no sea undefined o vacío
		if (!filename || filename === 'undefined' || typeof filename !== 'string') {
			return { error: new Error('Nombre de archivo inválido. Por favor selecciona un archivo válido.') };
		}

		// Sanitizar el nombre del archivo
		const sanitizedFilename = filename
			.replace(/[^\w\s.-]/g, '_')
			.replace(/\s+/g, '_')
			.replace(/_+/g, '_')
			.toLowerCase()
			.trim();

		if (!sanitizedFilename || sanitizedFilename === '_') {
			return { error: new Error('El nombre del archivo no es válido después de sanitizar.') };
		}

		// Obtener la sesión actual
		const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
		if (sessionErr || !sessionData?.session?.user?.id) {
			return { error: new Error('No autenticado. Por favor inicia sesión primero.') };
		}
		
		const currentUserId = sessionData.session.user.id;
		const userIdToUse = doctorUserId || currentUserId;

		if (!userIdToUse) {
			return { error: new Error('ID del médico requerido.') };
		}

		// Sanitizar el nombre del doctor para usarlo como nombre de carpeta
		const sanitizedDoctorName = (doctorName || userIdToUse)
			.replace(/[^\w\s-]/g, '_')
			.replace(/\s+/g, '_')
			.replace(/_+/g, '_')
			.toLowerCase()
			.trim();

		const folderName = sanitizedDoctorName || userIdToUse;

		// Construir ruta: certificados/{doctor_name}/{filename}
		const folder = `certificados/${folderName}`;
		const path = `${folder}/${sanitizedFilename}`;

		// Obtener el blob del archivo
		let uploadBody = fileUri;
		
		if (typeof fileUri === 'string') {
			console.log('Intentando fetch de URI:', fileUri);
			const response = await fetch(fileUri);
			if (!response.ok) {
				throw new Error(`HTTP ${response.status}: ${response.statusText}`);
			}
			uploadBody = await response.blob();
			console.log('Blob obtenido del fetch, tamaño:', uploadBody.size);
		} else {
			console.log('fileUri no es string, tipo:', typeof fileUri);
		}

		if (!uploadBody) {
			return { error: new Error('El archivo está vacío o no se pudo procesar.') };
		}
		
		console.log('Listos para subir, tipo:', uploadBody.constructor?.name, 'tamaño:', uploadBody.size);

		// Convertir Blob a base64 para compatibilidad con Supabase en Expo
		let base64Data = null;
		
		if (uploadBody.uri) {
			// Expo Blob tiene uri
			console.log('Leyendo archivo desde URI:', uploadBody.uri);
			const response = await fetch(uploadBody.uri);
			const blob = await response.blob();
			const reader = new FileReader();
			base64Data = await new Promise((resolve, reject) => {
				reader.onload = () => {
					const base64 = reader.result.split(',')[1];
					resolve(base64);
				};
				reader.onerror = reject;
				reader.readAsDataURL(blob);
			});
		} else if (uploadBody instanceof Blob) {
			// Blob estándar
			const reader = new FileReader();
			base64Data = await new Promise((resolve, reject) => {
				reader.onload = () => {
					const base64 = reader.result.split(',')[1];
					resolve(base64);
				};
				reader.onerror = reject;
				reader.readAsDataURL(uploadBody);
			});
		}
		
		if (!base64Data) {
			return { error: new Error('No se pudo convertir el archivo a base64.') };
		}
		
		console.log('Base64 listo, tamaño:', base64Data.length);
		
		// Convertir base64 a Uint8Array
		const binaryString = atob(base64Data);
		const bytes = new Uint8Array(binaryString.length);
		for (let i = 0; i < binaryString.length; i++) {
			bytes[i] = binaryString.charCodeAt(i);
		}
		
		// Upload
		return await uploadToSupabase(path, bytes, sanitizedFilename, userIdToUse, folderName, filename);
		
	} catch (e) {
		console.error('Error en uploadDoctorCertificate:', e);
		return { error: e };
	}
}

async function uploadToSupabase(path, fileBytes, sanitizedFilename, userIdToUse, folderName, filename) {
	try {
		console.log('Iniciando upload a:', path, 'tamaño:', fileBytes.length);
		
		const { data, error: uploadError } = await supabase.storage
			.from('docsDoctor')
			.upload(path, fileBytes, { 
				upsert: true,
				contentType: 'application/pdf'
			});

		if (uploadError) {
			console.error('Error de upload:', uploadError);
			return { error: uploadError };
		}

		console.log('Upload exitoso, data:', data);

		// Verificar que el archivo existe en el bucket
		const { data: fileList, error: listError } = await supabase.storage
			.from('docsDoctor')
			.list(`certificados/${folderName}`);

		if (listError) {
			console.warn('No se pudo verificar archivo en lista:', listError.message);
		} else {
			const fileExists = fileList.some(f => f.name === sanitizedFilename);
			if (fileExists) {
				console.log('✓ Archivo verificado en bucket:', sanitizedFilename);
			} else {
				console.warn('Archivo no encontrado en lista del bucket');
			}
		}

		// Obtener URL pública
		const { data: publicData } = supabase.storage.from('docsDoctor').getPublicUrl(path);
		console.log('✓ URL pública generada:', publicData?.publicUrl);
		
		return { publicUrl: publicData?.publicUrl ?? null };
	} catch (e) {
		console.error('Error en uploadToSupabase:', e);
		return { error: e };
	}
}

// Registra un nuevo paciente asociado a un médico
// El médico puede registrar pacientes en el sistema especificando sus datos
// Registra un nuevo paciente para validación
// Guarda el RUT en la tabla 'validacion' para que el paciente pueda habilitarlo después
export async function insertPatientByDoctor({ nombre, rut, doctor_user_id, diabetes_type, age }) {
	try {
		// Limpiar el RUT antes de guardar (usar la misma lógica que en otras funciones)
		const cleanedRut = rut.replace(/[^\dkK]/g, '').toUpperCase();
		
		// Separar RUT en cuerpo y dígito verificador
		const rutBody = cleanedRut.slice(0, -1); // RUT sin dígito verificador
		const digitoVerificador = cleanedRut.slice(-1); // Último dígito es el verificador
		
		// Validar que el RUT tenga al menos 2 caracteres
		if (cleanedRut.length < 2) {
			return { error: new Error('RUT inválido. Debe tener al menos 2 caracteres.') };
		}
		
		// Verificar que el doctor_user_id exista y obtener su RUT
		if (doctor_user_id) {
			const { data: doctorData, error: doctorErr } = await supabase
				.from('doctor')
				.select('rut')
				.eq('auth_user_id', doctor_user_id)
				.single();
			
			// Comparar solo si ambos RUTs son válidos
			if (doctorData && doctorData.rut && doctorData.rut === rutBody) {
				return { error: new Error('No puedes registrar a un paciente con tu propio RUT.') };
			}
		}
		
		// Guardar el RUT separado y todos los datos temporalmente en la tabla validacion
		const { data, error } = await supabase.from('validacion').insert([
			{
				rut: rutBody,
				digito_verificador: digitoVerificador,
				nombre: nombre || null,
				edad: age ? parseInt(age, 10) : null,
				diabetes_type: diabetes_type || null,
				doctor_user_id: doctor_user_id || null,
			}
		]).select();
		
		if (error) {
			return { error };
		}
		
		return { validacion: data?.[0] ?? null };
	} catch (e) {
		return { error: e };
	}
}

// Obtiene el RUT de un médico por su auth_user_id
export async function getDoctorRutByUserId(doctorUserId) {
	try {
		console.log('[getDoctorRutByUserId] Buscando RUT para doctor:', doctorUserId);
		
		const { data, error } = await supabase
			.from('doctor')
			.select('rut, digito_verificador')
			.eq('auth_user_id', doctorUserId)
			.maybeSingle();

		if (error) {
			console.error('[getDoctorRutByUserId] Error:', error.message);
			return { error };
		}

		if (data) {
			console.log('[getDoctorRutByUserId] RUT encontrado:', data.rut, 'DV:', data.digito_verificador);
			return { rut: data.rut, digito_verificador: data.digito_verificador };
		}

		console.warn('[getDoctorRutByUserId] No se encontró doctor');
		return { rut: null, digito_verificador: null };
	} catch (e) {
		console.error('[getDoctorRutByUserId] Exception:', e.message);
		return { error: e };
	}
}

// Busca un paciente existente por su RUT
// Se utiliza para verificar si un paciente ya fue registrado por algún médico
export async function findPatientByRut(rut) {
	try {
		const cleaned = rut.replace(/[^\dkK]/g, "").toUpperCase();
		// Separar el RUT en cuerpo y dígito verificador
		const rutBody = cleaned.slice(0, -1); // Solo el cuerpo del RUT
		const rutAsNumber = parseInt(rutBody); // Convertir a número
		
		console.log('[findPatientByRut] Buscando RUT:', rutAsNumber);
		
		// Buscar exacto por número (ya que la tabla paciente guarda rut como número)
		const { data, error } = await supabase.from('paciente').select('*').eq('rut', rutAsNumber).maybeSingle();
		
		if (error) {
			console.error('[findPatientByRut] Error en BD:', error.message);
			return { error };
		}
		
		if (data) {
			console.log('[findPatientByRut] ✓ Paciente encontrado');
			return { paciente: data };
		}
		
		// Si no encontró, obtener TODOS los pacientes para debugging
		console.log('[findPatientByRut] No encontrado, listando todos los pacientes...');
		const { data: allPatients, error: allError } = await supabase.from('paciente').select('rut, nombre, user_id');
		
		if (allError) {
			console.error('[findPatientByRut] Error al listar pacientes:', allError.message);
		}
		
		if (allPatients && allPatients.length > 0) {
			console.log('[findPatientByRut] Pacientes en BD:', allPatients.map(p => `RUT: ${p.rut}, Nombre: ${p.nombre}`));
		} else {
			console.log('[findPatientByRut] No hay pacientes en la BD (o error de RLS)');
		}
		
		console.log('[findPatientByRut] ✗ No hay paciente con RUT:', rutBody);
		return { paciente: null };
	} catch (e) {
		console.error('[findPatientByRut] Exception:', e.message);
		return { error: e };
	}
}

// Valida que un RUT esté en la tabla 'validacion' (fue registrado por un médico)
// Retorna los datos temporales guardados (nombre, edad, diabetes_type, etc.)
export async function validatePatientRutFromValidacion(rut) {
	try {
		const cleanedRut = rut.replace(/[^\dkK]/g, '').toUpperCase();
		// Separar RUT en cuerpo y dígito verificador
		const rutBody = cleanedRut.slice(0, -1);
		
		const { data, error } = await supabase.from('validacion').select('*').eq('rut', rutBody).maybeSingle();
		if (error) return { error };
		return { 
			isValid: data !== null, 
			validationData: data ?? null // Retorna todos los datos almacenados: nombre, edad, diabetes_type, doctor_user_id
		};
	} catch (e) {
		return { error: e };
	}
}

// Crea una cuenta de usuario para un paciente existente
// El paciente debe estar previamente registrado por un médico para usar esta función
// También crea automáticamente un tratamiento para el paciente
export async function createPatientAccount({ rut, age, password, email, diabetes_type }) {
	try {
		// Buscar si el paciente ya existe en el sistema (registrado por médico)
		const { paciente, error: findErr } = await findPatientByRut(rut);
		if (findErr) return { error: findErr };
		if (!paciente) return { error: new Error('RUT no registrado por ningún médico') };
		if (paciente.user_id) return { error: new Error('Paciente ya tiene cuenta') };

		// Definir email
		const emailToUse = (email && email.length > 3) ? email : (paciente.email && paciente.email.length > 3 ? paciente.email : `${rut}@mapi.local`);

		// Crear usuario de autenticación para el paciente
		const { data, error: signUpErr } = await supabase.auth.signUp({ email: emailToUse, password });
		if (signUpErr) return { error: signUpErr };
		const user = data?.user || null;

		// Preparar actualizaciones: agregar ID de usuario, edad y email del paciente
		const updates = { user_id: user?.id ?? null };
		if (age !== undefined) updates.age = age;

		if (emailToUse && (!paciente.email || paciente.email !== emailToUse)) {
			updates.email = emailToUse;
		}

		// Actualizar el tipo de diabetes si se proporciona
		if (diabetes_type !== undefined && diabetes_type !== null) {
			updates.diabetes_type = diabetes_type;
		}

		// Limpiar RUT para obtener solo el cuerpo (sin dígito verificador)
		const cleaned = rut.replace(/[^\dkK]/g, '').toUpperCase();
		const rutBody = cleaned.slice(0, -1);

		// Actualizar registro del paciente en la base de datos con su nuevo ID de usuario
		const { error: updateErr } = await supabase.from('paciente').update(updates).eq('rut', rutBody);
		if (updateErr) return { error: updateErr };

		// NOTA: La creación del tratamiento se maneja ahora en patientRegister.jsx
		// Esta función solo crea la cuenta del paciente y actualiza su perfil

		return { user, paciente: { ...paciente, ...updates } };
	} catch (e) {
		console.error('[createPatientAccount] Exception:', e.message);
		return { error: e };
	}
}

// Obtiene el tratamiento actual de un paciente
export async function getTratamientoByRutPaciente(rutPaciente) {
	try {
		const cleaned = rutPaciente.replace(/[^\dkK]/g, '').toUpperCase();
		const rutBody = cleaned.slice(0, -1);
		
		console.log('[getTratamientoByRutPaciente] Buscando tratamiento para RUT:', rutBody);
		
		const { data, error } = await supabase
			.from('tratamiento')
			.select('*')
			.eq('rut_paciente', rutBody)
			.order('fecha_inicio', { ascending: false })
			.maybeSingle();

		if (error) {
			console.error('[getTratamientoByRutPaciente] Error:', error.message);
			return { error };
		}

		if (data) {
			console.log('[getTratamientoByRutPaciente] ✓ Tratamiento encontrado:', data);
		} else {
			console.log('[getTratamientoByRutPaciente] ✗ No hay tratamiento para este RUT');
		}

		return { tratamiento: data ?? null };
	} catch (e) {
		console.error('[getTratamientoByRutPaciente] Exception:', e.message);
		return { error: e };
	}
}

// Obtiene todos los tratamientos de un médico
export async function getTratamientosByMedico(rutMedico) {
	try {
		// rutMedico ya viene limpio (sin dígito verificador) desde profile.rut
		// No necesita procesamiento adicional
		const rutBuscado = rutMedico;
		
		console.log('[getTratamientosByMedico] Buscando tratamientos del médico con RUT:', rutBuscado);
		
		const { data, error } = await supabase
			.from('tratamiento')
			.select('*')
			.eq('rut_medico', rutBuscado)
			.order('fecha_inicio', { ascending: false });

		if (error) {
			console.error('[getTratamientosByMedico] Error:', error.message);
			return { error };
		}

		console.log('[getTratamientosByMedico] Tratamientos encontrados:', data?.length || 0);
		return { tratamientos: data ?? [] };
	} catch (e) {
		console.error('[getTratamientosByMedico] Exception:', e.message);
		return { error: e };
	}
}

// Actualiza el tipo de diabetes en el tratamiento
export async function actualizarTipoDiabetesTratamiento(rutPaciente, tipoDiabetes) {
	try {
		const cleaned = rutPaciente.replace(/[^\dkK]/g, '').toUpperCase();
		const rutBody = cleaned.slice(0, -1);
		
		console.log('[actualizarTipoDiabetesTratamiento] Actualizando tipo diabetes para:', rutBody);
		
		const { error } = await supabase
			.from('tratamiento')
			.update({ tipo_diabetes: tipoDiabetes })
			.eq('rut_paciente', rutBody);

		if (error) {
			console.error('[actualizarTipoDiabetesTratamiento] Error:', error.message);
			return { error };
		}

		console.log('[actualizarTipoDiabetesTratamiento] ✓ Actualizado exitosamente');
		return { success: true };
	} catch (e) {
		console.error('[actualizarTipoDiabetesTratamiento] Exception:', e.message);
		return { error: e };
	}
}

// Obtiene los certificados subidos por un médico en el bucket
export async function getDoctorCertificates(doctorUserId, doctorName) {
	try {
		if (!doctorName && !doctorUserId) {
			return { certificates: [] };
		}
		// Sanitizar el nombre del doctor para usarlo como nombre de carpeta
		const sanitizedDoctorName = (doctorName || doctorUserId)
			.replace(/[^\w\s-]/g, '_')
			.replace(/\s+/g, '_')
			.replace(/_+/g, '_')
			.toLowerCase()
			.trim();

		const folderPath = `certificados/${sanitizedDoctorName}`;
		const { data, error } = await supabase.storage
			.from('docsDoctor')
			.list(folderPath);

		if (error) {
			// Si la carpeta no existe, retornar vacío
			return { certificates: [] };
		}

		// Filtrar solo archivos (no carpetas)
		const files = data.filter(item => !item.metadata?.mimetype || item.metadata.mimetype.includes('pdf'));
		return { certificates: files };
	} catch (e) {
		console.error('Error al obtener certificados:', e);
		return { certificates: [] };
	}
}

// Obtiene la URL pública de un certificado
export async function getCertificateUrl(doctorUserId, filename, doctorName) {
	try {
		// Sanitizar el nombre del doctor
		const sanitizedDoctorName = (doctorName || doctorUserId)
			.replace(/[^\w\s-]/g, '_')
			.replace(/\s+/g, '_')
			.replace(/_+/g, '_')
			.toLowerCase()
			.trim();

		const path = `certificados/${sanitizedDoctorName}/${filename}`;
		const { data } = supabase.storage.from('docsDoctor').getPublicUrl(path);
		return { publicUrl: data?.publicUrl ?? null };
	} catch (e) {
		return { error: e };
	}
}

// Elimina un certificado del bucket
export async function deleteDoctorCertificate(doctorUserId, filename, doctorName) {
	try {
		// Obtener la sesión actual para verificar que es el propietario
		const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
		if (sessionErr || !sessionData?.session?.user?.id) {
			return { error: new Error('No autenticado. Por favor inicia sesión primero.') };
		}
		
		const currentUserId = sessionData.session.user.id;
		
		// Verificar que el usuario intenta eliminar sus propios certificados
		if (currentUserId !== doctorUserId) {
			return { error: new Error('No tienes permiso para eliminar este certificado.') };
		}

		// Sanitizar el nombre del doctor
		const sanitizedDoctorName = (doctorName || doctorUserId)
			.replace(/[^\w\s-]/g, '_')
			.replace(/\s+/g, '_')
			.replace(/_+/g, '_')
			.toLowerCase()
			.trim();

		const path = `certificados/${sanitizedDoctorName}/${filename}`;
		
		console.log('Eliminando certificado:', path);
		
		const { error } = await supabase.storage
			.from('docsDoctor')
			.remove([path]);

		if (error) {
			console.error('Error al eliminar certificado:', error);
			return { error };
		}

		console.log('✓ Certificado eliminado correctamente:', filename);
		
		// Verificar si la carpeta está vacía y eliminarla si es así
		const folderPath = `certificados/${sanitizedDoctorName}`;
		const { data: remainingFiles, error: listError } = await supabase.storage
			.from('docsDoctor')
			.list(folderPath);

		if (!listError && remainingFiles && remainingFiles.length === 0) {
			console.log('Carpeta vacía, eliminando carpeta:', folderPath);
			// Supabase no permite eliminar carpetas vacías directamente,
			// pero la carpeta se considera eliminada si no contiene archivos
			// El sistema la mostrará como inexistente
		}
		
		// Limpiar el campo certificado_url en la tabla doctor
		const { error: updateError } = await supabase
			.from('doctor')
			.update({ certificado_url: null })
			.eq('auth_user_id', doctorUserId);
		
		if (updateError) {
			console.warn('No se pudo actualizar certificado_url:', updateError);
		}
		
		return { success: true };
	} catch (e) {
		console.error('Error en deleteDoctorCertificate:', e);
		return { error: e };
	}
}

// Actualiza el campo certificado_url en la tabla doctor
export async function updateDoctorCertificateUrl(doctorUserId, certificateUrl) {
	try {
		const { error } = await supabase
			.from('doctor')
			.update({ certificado_url: certificateUrl })
			.eq('auth_user_id', doctorUserId);
		
		if (error) {
			console.error('Error al actualizar certificado_url:', error);
			return { error };
		}
		
		console.log('✓ Campo certificado_url actualizado:', certificateUrl);
		return { success: true };
	} catch (e) {
		console.error('Error en updateDoctorCertificateUrl:', e);
		return { error: e };
	}
}

// Sube un documento de un paciente al bucket `docsPatient`
// Solo los médicos pueden subir documentos de sus pacientes
export async function uploadPatientDocument({ fileUri, filename, patientId, patientName }) {
	try {
		// Validar que el filename no sea undefined o vacío
		if (!filename || filename === 'undefined' || typeof filename !== 'string') {
			return { error: new Error('Nombre de archivo inválido. Por favor selecciona un archivo válido.') };
		}

		if (!patientId) {
			return { error: new Error('ID del paciente requerido.') };
		}

		// Usar nombre del paciente si se proporciona, si no usar patientId
		const folderName = patientName || patientId;

		// Sanitizar el nombre del archivo
		const sanitizedFilename = filename
			.replace(/[^\w\s.-]/g, '_')
			.replace(/\s+/g, '_')
			.replace(/_+/g, '_')
			.toLowerCase()
			.trim();

		if (!sanitizedFilename || sanitizedFilename === '_') {
			return { error: new Error('El nombre del archivo no es válido después de sanitizar.') };
		}

		// Obtener la sesión actual (solo médicos autenticados)
		const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
		if (sessionErr || !sessionData?.session?.user?.id) {
			return { error: new Error('No autenticado. Por favor inicia sesión primero.') };
		}

		// Construir ruta
		const path = `documentos/${folderName}/${sanitizedFilename}`;

		// Obtener el blob del archivo
		let uploadBody = fileUri;
		
		if (typeof fileUri === 'string') {
			console.log('Intentando fetch de URI:', fileUri);
			const response = await fetch(fileUri);
			if (!response.ok) {
				throw new Error(`HTTP ${response.status}: ${response.statusText}`);
			}
			uploadBody = await response.blob();
			console.log('Blob obtenido del fetch, tamaño:', uploadBody.size);
		}

		if (!uploadBody) {
			return { error: new Error('El archivo está vacío o no se pudo procesar.') };
		}
		
		console.log('Listos para subir, tipo:', uploadBody.constructor?.name, 'tamaño:', uploadBody.size);

		// Convertir Blob a base64 para compatibilidad con Supabase en Expo (Mobile)
		let base64Data = null;
		
		if (uploadBody.uri) {
			// Expo Blob tiene uri
			console.log('Leyendo archivo desde URI:', uploadBody.uri);
			const response = await fetch(uploadBody.uri);
			const blob = await response.blob();
			const reader = new FileReader();
			base64Data = await new Promise((resolve, reject) => {
				reader.onload = () => {
					const base64 = reader.result.split(',')[1];
					resolve(base64);
				};
				reader.onerror = reject;
				reader.readAsDataURL(blob);
			});
		} else if (uploadBody instanceof Blob) {
			// Blob estándar
			const reader = new FileReader();
			base64Data = await new Promise((resolve, reject) => {
				reader.onload = () => {
					const base64 = reader.result.split(',')[1];
					resolve(base64);
				};
				reader.onerror = reject;
				reader.readAsDataURL(uploadBody);
			});
		}
		
		if (!base64Data) {
			return { error: new Error('No se pudo convertir el archivo a base64.') };
		}
		
		console.log('Base64 listo, tamaño:', base64Data.length);
		
		// Convertir base64 a Uint8Array
		const binaryString = atob(base64Data);
		const bytes = new Uint8Array(binaryString.length);
		for (let i = 0; i < binaryString.length; i++) {
			bytes[i] = binaryString.charCodeAt(i);
		}
		
		// Upload
		return await uploadPatientDocumentToSupabase(path, bytes, sanitizedFilename, filename);
		
	} catch (e) {
		console.error('Error en uploadPatientDocument:', e);
		return { error: e };
	}
}

async function uploadPatientDocumentToSupabase(path, fileBytes, sanitizedFilename, filename) {
	try {
		console.log('Iniciando upload a:', path, 'tamaño:', fileBytes.length);
		
		const { data, error: uploadError } = await supabase.storage
			.from('docsPatient')
			.upload(path, fileBytes, { 
				upsert: true,
				contentType: 'application/pdf'
			});

		if (uploadError) {
			console.error('Error de upload:', uploadError);
			return { error: uploadError };
		}

		console.log('Upload exitoso, data:', data);

		// Obtener URL pública
		const { data: publicData } = supabase.storage.from('docsPatient').getPublicUrl(path);
		console.log('✓ URL pública generada:', publicData?.publicUrl);
		
		return { publicUrl: publicData?.publicUrl ?? null };
	} catch (e) {
		console.error('Error en uploadPatientDocumentToSupabase:', e);
		return { error: e };
	}
}

// Obtiene los documentos de un paciente
export async function getPatientDocuments(patientName) {
	try {
		const folderPath = `documentos/${patientName}`;
		const { data, error } = await supabase.storage
			.from('docsPatient')
			.list(folderPath);

		if (error) {
			// Si la carpeta no existe, retornar vacío
			return { documents: [] };
		}

		// Filtrar solo archivos (no carpetas)
		const files = data.filter(item => !item.metadata?.mimetype || item.metadata.mimetype.includes('pdf'));
		return { documents: files };
	} catch (e) {
		console.error('Error al obtener documentos del paciente:', e);
		return { documents: [] };
	}
}

// Obtiene la URL pública de un documento de paciente
export async function getPatientDocumentUrl(patientName, filename) {
	try {
		const path = `documentos/${patientName}/${filename}`;
		const { data } = supabase.storage.from('docsPatient').getPublicUrl(path);
		return { publicUrl: data?.publicUrl ?? null };
	} catch (e) {
		return { error: e };
	}
}

// Elimina un documento de un paciente
export async function deletePatientDocument(patientName, filename) {
	try {
		// Obtener la sesión actual para verificar que es un médico autenticado
		const { data: sessionData, error: sessionErr } = await supabase.auth.getSession();
		if (sessionErr || !sessionData?.session?.user?.id) {
			return { error: new Error('No autenticado. Por favor inicia sesión primero.') };
		}

		const path = `documentos/${patientName}/${filename}`;
		
		console.log('Eliminando documento:', path);
		
		const { error } = await supabase.storage
			.from('docsPatient')
			.remove([path]);

		if (error) {
			console.error('Error al eliminar documento:', error);
			return { error };
		}

		console.log('✓ Documento eliminado correctamente:', filename);
		return { success: true };
	} catch (e) {
		console.error('Error en deletePatientDocument:', e);
		return { error: e };
	}
}

// Finalizar un tratamiento (moverlo de tratamiento a registro_tratamiento)
export async function finalizarTratamiento(idTratamiento) {
	try {
		// Obtener el tratamiento actual
		const { data: tratamiento, error: fetchErr } = await supabase
			.from('tratamiento')
			.select('*')
			.eq('id_tratamiento', idTratamiento)
			.single();

		if (fetchErr || !tratamiento) {
			console.error('[finalizarTratamiento] Error al obtener tratamiento:', fetchErr?.message);
			return { error: 'Tratamiento no encontrado' };
		}

		// Insertar en registro_tratamiento con fecha_fin
		const { error: insertErr } = await supabase
			.from('registro_tratamiento')
			.insert([
				{
					...tratamiento,
					fecha_fin: new Date().toISOString(),
				}
			]);

		if (insertErr) {
			console.error('[finalizarTratamiento] Error al insertar en registro:', insertErr.message);
			return { error: 'Error al guardar el registro' };
		}

		// Eliminar de tratamiento
		const { error: deleteErr } = await supabase
			.from('tratamiento')
			.delete()
			.eq('id_tratamiento', idTratamiento);

		if (deleteErr) {
			console.error('[finalizarTratamiento] Error al eliminar tratamiento:', deleteErr.message);
			return { error: 'Error al finalizar tratamiento' };
		}

		console.log('[finalizarTratamiento] ✓ Tratamiento finalizado:', idTratamiento);
		return { success: true };
	} catch (e) {
		console.error('[finalizarTratamiento] Exception:', e.message);
		return { error: e.message };
	}
}