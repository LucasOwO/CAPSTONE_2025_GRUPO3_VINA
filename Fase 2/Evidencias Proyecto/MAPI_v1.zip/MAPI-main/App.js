// Use expo-router entry to enable file-system based routing under the `app/` folder.
// This keeps behavior consistent with `package.json` which sets "main": "expo-router/entry".
export { default } from 'expo-router/entry';

